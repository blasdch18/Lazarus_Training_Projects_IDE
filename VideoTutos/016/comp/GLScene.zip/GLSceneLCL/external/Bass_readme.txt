BASS 2.4.10
Copyright (c) 1999-2014 Un4seen Developments Ltd. All rights reserved.
  -----------------------------

  Questions, suggestions, etc. regarding the Delphi API
  can be sent to magicrt@hotmail.com

  See the BASS.CHM file for more complete documentation

  NOTE: This unit will work with BASS.DLL versions 1.6a-2.4.1
  Check http://www.un4seen.com/music/ for any later
  versions of BASS.PAS