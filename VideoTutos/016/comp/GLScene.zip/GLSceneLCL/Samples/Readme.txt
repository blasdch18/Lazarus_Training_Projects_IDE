Samples/Demos for using GLScene with Lazarus

For all this demos it supposed that  
- example projects are in ..\GLSceneLCL\Samples\Lazarus directory;
- media files are in ..\GLSceneLCL\Samples\media;

Additional Dynamic libraries, dll are in ..\GLSceneLCL\external directory

All the files are released under Mozilla PL (MPL).
GLScene is an open-source graphic library.

http://glscene.org
http://sourceforge.net/projects/glscene






